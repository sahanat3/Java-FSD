package com.ecommerce.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;


@Controller
public class MainController {
		   
	  @RequestMapping(value = "/")
	    public String index() {
	        return "index.html";
	    }
	       
	  @RequestMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	  @ResponseBody   
	  public String fileUpload(@RequestParam("file") MultipartFile file) {
	                String result = "File was uploaded successfully";
	                
	                try {
	                  File convertFile = new File("/var/tmp/"+file.getOriginalFilename());
		              convertFile.createNewFile();
		              FileOutputStream fout = new FileOutputStream(convertFile);
		              fout.write(file.getBytes());
		              fout.close();
	              
	                } catch (IOException iex) {
	                        result = "Error " + iex.getMessage();
	                }
                        return result;
                }

        
	    @RequestMapping(value = "/download", method = RequestMethod.GET)
        public ResponseEntity<Object> downloadFile() throws IOException  {
                String fileName = "static/dump.txt";
                Resource resource = new ClassPathResource(fileName);
                InputStream inputStream = resource.getInputStream();

                HttpHeaders headers = new HttpHeaders();
                headers.add("Content-Disposition", "attachment; filename=dump.txt");

                return ResponseEntity
                        .ok()
                        .headers(headers)
                        .contentType(MediaType.parseMediaType("application/txt"))
                        .body(new InputStreamResource(inputStream));
            }
}