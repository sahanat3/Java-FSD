

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class LoginServlet
 */

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public LoginServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        response.setContentType("text/html");
	        PrintWriter out = response.getWriter();

	        String username = request.getParameter("username");
	        String password = request.getParameter("password");
	        if (username != null && !username.isEmpty() && password != null && !password.isEmpty()) {
	           
	        	// Create a session and store the username as a session attribute
	            HttpSession session = request.getSession();
	            session.setAttribute("username", username);
	            out.println("<h1>Welcome, " + username + "!</h1>");
	            out.println("<p><a href='LogoutServlet'>Logout</a></p>");
	        } else {
	            out.println("<h1>Login Failed</h1>");
	            out.println("<p>Please enter a valid username and password.</p>");
	            out.println("<p><a href='index.html'>Back to Login</a></p>");
	        }
	    }
	}

