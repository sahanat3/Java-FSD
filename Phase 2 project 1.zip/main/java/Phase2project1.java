

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * 1 Write a program to demonstrate the differences between GET and POST using Servlet.
 */
public class Phase2project1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// GET method
		response.setContentType("text/html");
		String name = request.getParameter("name");
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
        out.println("<head><title>GET</title></head>");
        out.println("<body>");
        out.println("<h1>GET Method</h1>");
        out.println("<p>Hello, " + name + ". You've reachead GET method.</p>");
        out.println("</body></html>");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// POST method
		response.setContentType("text/html");
		String name = request.getParameter("name");
		PrintWriter out = response.getWriter();
		
		 out.println("<html>");
	     out.println("<head><title>POST</title></head>");
	     out.println("<body>");
	     out.println("<h1>POST Method</h1>");
	     out.println("<p>Hello, " + name + ". You've reachead POST method.</p>");
	     out.println("</body></html>");
	}

}
