

import jakarta.servlet.ServletException;
import java.io.IOException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 4 Write a program to demonstrate the concept of Servlet Classes and Interfaces.
 */
public class Phase2project4 extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
   	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   	 response.setContentType("text/html");
   	 
     jakarta.servlet.ServletConfig config = getServletConfig();
     String servletName = config.getServletName();
     
     jakarta.servlet.ServletContext context = getServletContext();
     String appName = context.getServletContextName();
	
     String htmlResponse = "<html><head><title>Servlet Demo</title></head><body>"
             + "<h5>Hello from Servlet</h5>"
             + "<p>Servlet Name: " + servletName + "</p>"
             + "<p>Application Name: " + appName + "</p>"
             + "</body></html>";

     response.getWriter().write(htmlResponse);
  }
}

	
