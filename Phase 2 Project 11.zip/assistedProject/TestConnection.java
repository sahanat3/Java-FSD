package assistedProject;

import java.sql.Connection;
import java.sql.DriverManager;

public class TestConnection {

	public static void main(String[] args) {
		try
		{
		//Registering Driver
		Class.forName("com.mysql.cj.jdbc.Driver");
		//Making Connection 
		Connection  conObj  = DriverManager.getConnection("jdbc:mysql://localhost:3306/JAVAFSD1", "root", "123456789");

		if(conObj!=null)
			System.out.println("Connected.....");
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}

}