

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class URLrewrite
 */
@WebServlet("/rewrite/")
public class URLrewrite extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public URLrewrite() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		    response.setContentType("text/html");
	        PrintWriter out = response.getWriter();

	        HttpSession session = request.getSession();
	        
	        // Retrieve the existing session ID from the session
	        String sessionID = session.getId();

	        // Create a URL with the session ID 
	        String urlWithSessionID = response.encodeURL("WelcomeServlet");

	        out.println("<h1>Welcome to Session Tracking with URL Rewriting</h1>");
	        out.println("<p>Your session ID is: " + sessionID + "</p>");
	        out.println("<p><a href='" + urlWithSessionID + "'>Go to Welcome Page</a></p>");
	    }
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
