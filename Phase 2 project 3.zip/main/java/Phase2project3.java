

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * 3 Write a program to demonstrate the concept of Generic Servlets
 */
public class Phase2project3 extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
   
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String protocol = request.getProtocol();
	
		if (protocol.startsWith("HTTP/")) {
            out.println("<html><head><title>Generic Servlet Conceptes Example</title></head><body>");
            out.println("<h4>Generic Servlet</h4>");
            out.println("<p>This is a Generic Servlet example.</p>");
            out.println("<p>Protocol used: " + protocol + "</p>");
            out.println("</body></html>");
        } else {
            out.println("Unsupported protocol: " + protocol);
        }
    }
}
