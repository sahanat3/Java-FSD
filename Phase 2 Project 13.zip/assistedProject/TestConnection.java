package assistedProject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class TestConnection {

	public static void main(String[] args) {
		    String url = "jdbc:mysql://localhost:3306/newEmployees";
	        String username = "root";
	        String password = "123456789";
	        
	 try(Connection  conObj  = DriverManager.getConnection(url, username, password);

		Statement statement = conObj.createStatement()){

        ResultSet resultSet = statement.executeQuery("SELECT id, name FROM newEmployees");

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                System.out.println("ID: " + id + ", Name: " + name);
            }
            
            } catch (Exception e) {
            e.printStackTrace();
        }
	}
}
