

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

/**
 * 9 Write a program to demonstrate Session Tracking using an HTTP Session.
 */

@WebServlet("/SessionTrackingServelet")
public class SessionTrackingServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SessionTrackingServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		    response.setContentType("text/html");
	        PrintWriter out = response.getWriter();

	        HttpSession session = request.getSession();
	        
	        String sessionAttribute = (String) session.getAttribute("mySessionAttribute");

	        if (sessionAttribute == null) {
	            // If the session attribute doesn't exist, create and set it
	            sessionAttribute = "This is my session attribute!";
	            session.setAttribute("mySessionAttribute", sessionAttribute);
	            out.println("<h1>Session Attribute Set</h1>");
	        } else {
	            // If the session attribute already exists, display it
	            out.println("<h1>Session Attribute Already Exists</h1>");
	            out.println("<p>Session Attribute: " + sessionAttribute + "</p>");
	        }
	        out.println("<p><a href='ShowSessionAttribute'>Show Session Attribute</a></p>");
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
