/**
 * 
 */
/**
 * 
 */
module JDBCproject {
	requires java.sql;
}