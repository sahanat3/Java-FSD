package assistedProject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class TestConnection {

	public static void main(String[] args) {
		try
		{
		//Registering Driver
		Class.forName("com.mysql.cj.jdbc.Driver");
		//Making Connection 
		Connection  conObj  = DriverManager.getConnection("jdbc:mysql://localhost:3306/JAVAFSD1", "root", "123456789");

		if(conObj!=null)
			System.out.println("Connected.....");
		
			String insertQuery = "INSERT INTO demo1 (id, string) VALUES (?, ?)";
			PreparedStatement preparedStatement = conObj.prepareStatement(insertQuery);
        
			 preparedStatement.setInt(1, 1); 
             preparedStatement.setString(2, "john"); 
             
             int rowsAffected = preparedStatement.executeUpdate();

             if (rowsAffected > 0) {
                 System.out.println("Data inserted successfully!");
             } else {
                 System.out.println("Failed to insert data.");
             }
             preparedStatement.close();
             }
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}

}